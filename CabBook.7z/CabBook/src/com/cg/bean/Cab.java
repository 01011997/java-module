package com.cg.bean;

public class Cab {
	private String cabType;
	private String driverName;
	private String customerName;
	private int OTP;
	private String Pl;
	private String Dl;
	private int price;

	@Override
	public String toString() {
		return "Cab [cabType=" + cabType + ", driverName=" + driverName + ", customerName=" + customerName + ", OTP="
				+ OTP + ", Pl=" + Pl + ", Dl=" + Dl + ", price=" + price + "]";
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Cab(String cabType, String driverName, String pl) {
		super();
		this.cabType = cabType;
		this.driverName = driverName;
		Pl = pl;
	}
	public Cab(String cabType, String driverName, String customerName, int oTP, String pl, String dl) {
		super();
		this.cabType = cabType;
		this.driverName = driverName;
		this.customerName = customerName;
		OTP = oTP;
		Pl = pl;
		Dl = dl;
	}
	public String getPl() {
		return Pl;
	}
	public void setPl(String pl) {
		Pl = pl;
	}
	public String getDl() {
		return Dl;
	}
	public void setDl(String dl) {
		Dl = dl;
	}
	public String getCabType() {
		return cabType;
	}
	public void setCabType(String cabType) {
		this.cabType = cabType;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getOTP() {
		return OTP;
	}
	public void setOTP(int oTP) {
		OTP = oTP;
	}

	public Cab() {
		super();
		// TODO Auto-generated constructor stub
	}
}
