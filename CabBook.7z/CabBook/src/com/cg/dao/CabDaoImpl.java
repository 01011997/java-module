package com.cg.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.cg.bean.Cab;
import com.cg.exception.CMSException;

import com.cg.util.Util;

public class CabDaoImpl implements ICabDAO {
	Util util=new Util();
	private static Map<Integer,Cab >map= Util.getMap();
	
	
	@Override
	public String validatepl(String pUp) throws CMSException {
		// TODO Auto-generated method stub
		boolean availability=false;
		for(Cab c:map.values())
		{
			if(c.getPl().equalsIgnoreCase(pUp))
				availability=true;
				
			
		}
		if(availability) {
			System.out.println("Cab Available.");
		}
		else
			System.out.println("Cab Not Available.");
		return pUp;
	}


	

	@Override
	public Cab getOrderDetails(int otp2) throws CMSException {
		Cab otp = map.get(otp2);
		/*boolean flag = false;
	
		Set<Integer> set = map.keySet();
		for (int otp1 : set) {
			if (otp1 == otp2) {
				
				Cab o = map.get(otp1);
				//int custId = order2.getCustomerId();
				
				//Customer customer = customers.get(custId);
				
				otp = map.get(otp1);
				
				break;
			}
		}

		if (otp == null) {
			throw new CMSException("no booking present with the given id");
		}
*/
		
		
		return otp;
	}




	@Override
	public void addData(Cab cab) {
		for(Cab c:map.values())
		{
			if(c.getPl().equalsIgnoreCase(cab.getPl())) {
				
				cab.setDriverName(c.getDriverName());
				cab.setCabType(c.getCabType());
			}
		}	
		map.put(cab.getOTP(), cab);
		
	}



//	@Override
//	public Cab getorderDetails() {
//		// TODO Auto-generated method stub
//		return Util.getMap();
//	}

}
