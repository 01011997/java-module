package com.cg.service;

import java.util.regex.Pattern;

import com.cg.bean.Cab;
import com.cg.dao.CabDaoImpl;
import com.cg.dao.ICabDAO;
import com.cg.exception.CMSException;





public class cabServiceImpl implements cabService {

	
	ICabDAO dao=new CabDaoImpl();
	@Override
	public void validateName(String name) throws CMSException {
		
			String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
			if (!Pattern.matches(nameRegEx, name)) {
				throw new CMSException("first letter should be capital and length must be in between 5 to 10");
			}
		}
		
	

	@Override
	public Object validatepl(String pl) throws CMSException {
		// TODO Auto-generated method stub
		return dao.validatepl(pl);
	}

	@Override
	public void validatedl(String dl) throws CMSException {
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, dl) == false) {
			throw new CMSException("name should contain only alphabets");
		}
		// TODO Auto-generated method stub
		
	}
//
//	@Override
//	public Cab getorderDetails() {
//		// TODO Auto-generated method stub
//		return dao.getorderDetails();
//	}



	@Override
	public void validateotp(int otp1) throws CMSException {
		// TODO Auto-generated method stub
		String idRegEx = "[0-9]+";
		if (Pattern.matches(idRegEx, String.valueOf(otp1)) == false) {
			throw new CMSException("orderid should contain only digits");
		}
	}



	@Override
	public Cab getorderDetails(int otp2) throws CMSException {
		// TODO Auto-generated method stub
		return dao.getOrderDetails(otp2);
	}



	@Override
	public void addData(Cab cab) {
		// TODO Auto-generated method stub
		dao.addData(cab);
	}

	
	

}
