package com.cg.service;

import com.cg.bean.Cab;
import com.cg.exception.CMSException;

public interface cabService {

	
	void validateName(String name) throws CMSException;

	Object validatepl(String pl)throws CMSException;

	void validatedl(String dl)throws CMSException;

	void validateotp(int otp1)throws CMSException;

	Cab getorderDetails(int otp2)throws CMSException;

	void addData(Cab cab);

	//Cab getorderDetails();

	//Cab bookcab(Cab cab)throws CMSException;

}
