package com.cg.exception;

public class CMSException extends Exception
{
	public CMSException(String message) {
		super(message);
	}
}
