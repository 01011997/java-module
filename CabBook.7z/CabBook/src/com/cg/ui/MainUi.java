package com.cg.ui;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import com.cg.bean.Cab;
import com.cg.exception.CMSException;

import com.cg.service.cabService;
import com.cg.service.cabServiceImpl;


public class MainUi {

	public static void main(String[] args) {
		int otp=0;
		Scanner scanner = null;

		String continueChoice = "";
		cabService service = new cabServiceImpl();
		do {
			System.out.println("1.Book Cab");
			System.out.println("2.display Booking");
			System.out.println("3.Exit");

			int choice = 0;
			boolean choiceFlag = false;
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					String name = "";

					switch (choice) {
					case 1:
						
						boolean nameFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter name of the customer");
							name = scanner.nextLine();
							try {
								service.validateName(name);
								nameFlag = true;
								break;

							} catch (CMSException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);
						
						
						String pl = "";
						boolean plFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter pl of the customer");
							pl = scanner.nextLine();
							try {
								service.validatepl(pl);
								plFlag = true;
								break;

							} catch (CMSException e) {
								plFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!plFlag);
						
						String dl = "";
						boolean dlFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter drop location of the customer");
							dl = scanner.nextLine();
							try {
								service.validatedl(dl);
								dlFlag = true;
								break;

							} catch (CMSException e) {
								dlFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!dlFlag);
						
						Cab cab = new Cab(name,pl,dl);
						

							//Cab cab1 = service.bookcab(cab);
							otp= (int) (Math.random()*1000);
							int price= (int) (Math.random()*1000);
							cab.setOTP(otp);
							cab.setPrice(price);
							cab.setCustomerName(name);
							cab.setPl(pl);
							cab.setDl(dl);
							service.addData(cab);
							
							System.out.println("booking done with otp " +otp);
							System.out.println("booking done with price "+price);
					

						LocalDate localDate = LocalDate.now();
						System.out.println("Booking date:" + localDate);

						

						break;

					case 2:
						int otp2 = 0;
						boolean otpFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter OTP");
							try {
								otp2 = scanner.nextInt();
								service.validateotp(otp2);
								otpFlag = true;
								break;

							} catch (InputMismatchException e) {
								otpFlag = false;
								System.err.println(e.getMessage());
							} catch (CMSException e) {
								System.err.println(e.getMessage());
							}

						} while (!otpFlag);

						try {
							Cab cab1 = service.getorderDetails(otp2);
							
								
							
							System.out.println(cab1.getCustomerName());
							System.out.println(cab1.getCabType());
							System.out.println(cab1.getDriverName());
							System.out.println(cab1.getPrice());
							System.out.println(cab1.getPl());
							System.out.println(cab1.getDl());

						} catch (CMSException e) {
							System.err.println(e.getMessage());
						}

					
						break;
					case 4:
						

					case 3:
						System.exit(0);

					default:
						System.out.println("Enter 1,2 or 3");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("enter only digits");
				}

				
			}while(!choiceFlag);

			
			
			
			
			scanner = new Scanner(System.in);
			System.out.println("do u want to continue again(yes/no)");
			continueChoice = scanner.next();	
		}while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}

}
