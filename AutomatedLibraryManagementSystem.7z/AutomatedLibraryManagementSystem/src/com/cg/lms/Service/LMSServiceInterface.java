package com.cg.lms.Service;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import com.cg.lms.Bean.Book;
import com.cg.lms.Exception.LMSException;

public interface LMSServiceInterface {
	public void validateRollNo(String rollNo) throws LMSException;
	public void validateStudentName(String rollNo) throws LMSException;
	public void validateBookName(String rollNo) throws LMSException;
	public Book searchBookName(String availBookName) throws LMSException;
   public CopyOnWriteArrayList<Book> getAllBooks() throws LMSException;
   public Book removeBookName(Book deleteBook) throws LMSException;
//void validateStudentName(String studentName) throws LMSException;
}
