package com.cg.pms.bean;

import java.util.Comparator;

public class Product {

	private int id;
	private String name;
	private double price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int id, String name, double price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		return true;
	}

	
	public static Comparator<Product> PriceComparator = new Comparator<Product>() {
		public int compare(Product p1, Product p2) {
			double price1=p1.getPrice();
			double price2=p2.getPrice();
			
			return Double.compare(price1, price2);
		} 
		
	};

	public static Comparator<Product> IdComparator = new Comparator<Product>() {
		public int compare(Product p1, Product p2) {
			int id1=p1.getId();
			int id2=p2.getId();
			
			return Integer.compare(id1, id2);
			
		}
	};

	public static Comparator<Product> NameComparator = new Comparator<Product>() {
		public int compare(Product p1, Product p2) {
			String name1=p1.getName();
			String name2=p2.getName();
			
			return name1.compareTo(name2);
		
		} 
		
	};
	
	

}