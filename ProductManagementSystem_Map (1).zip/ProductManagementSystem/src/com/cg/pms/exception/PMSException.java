package com.cg.pms.exception;

public class PMSException extends Exception {
	public PMSException(String message) {
		super(message);
	}
}
