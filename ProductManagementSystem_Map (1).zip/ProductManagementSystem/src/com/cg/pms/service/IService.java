package com.cg.pms.service;

import java.util.List;
import java.util.Map;

import com.cg.pms.bean.Product;

public interface IService {

	public Map<Integer,Product> displayAll();

	public Product searchProduct(int prodId);

	public Product removeProduct(int prodId);
}
