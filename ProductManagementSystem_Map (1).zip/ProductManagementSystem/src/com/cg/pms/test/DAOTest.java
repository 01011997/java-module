package com.cg.pms.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.pms.dao.DAO;
import com.cg.pms.dao.IDAO;

public class DAOTest {
	IDAO dao;
	@Before
	public void setUp() throws Exception {
		dao=new DAO();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}

	@Test
	public void testDisplayAll() {
		assertNotNull(dao.displayAll());

	}

	@Test
	public void testSearchProduct() {
		assertNotNull(dao.searchProduct(5));
	}

	@Test
	public void testSearchProduct2() {
		assertNull(dao.searchProduct(8));
	}
	
	@Test
	public void testRemoveProduct() {
		assertNotNull(dao.removeProduct(1));
	}
	
	@Test
	public void testRemoveProduct2() {
		assertNull(dao.removeProduct(9));
	}

}
